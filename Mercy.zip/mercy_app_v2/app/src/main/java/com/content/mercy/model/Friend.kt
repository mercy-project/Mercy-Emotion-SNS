package com.content.mercy.model

/**
 * Created by rapsealk on 2019-11-03..
 */
class Friend(
    uid: String,
    name: String?
) : User(uid, name)