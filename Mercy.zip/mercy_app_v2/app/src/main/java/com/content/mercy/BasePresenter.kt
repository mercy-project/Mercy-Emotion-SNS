package com.content.mercy

/**
 * Created by rapsealk on 2019-11-01..
 */
interface BasePresenter {

    fun start()
}