package com.content.mercy.model

/**
 * Created by rapsealk on 2019-11-03..
 */
open class User(
    val uid: String,
    var name: String?
)