package com.content.mercy.camera

/**
 * Created by rapsealk on 2019-11-02..
 */
class CameraPresenter(private val view: CameraContract.View) : CameraContract.Presenter {

    init { start() }

    override fun start() {

    }
}